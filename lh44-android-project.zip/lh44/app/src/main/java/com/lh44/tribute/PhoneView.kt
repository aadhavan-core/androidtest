package com.lh44.tribute

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------------------
// Palette (taken from the Figma export)
// ---------------------------------------------------------------------------
private val Ink = Color(0xff050505)
private val Panel = Color(0xff0c0b0a)
private val PanelWarm = Color(0xff14110f)
private val Paper = Color(0xfff1eee8)
private val Ember = Color(0xffff5a1f)
private val Rust = Color(0xffb62d08)
private val Stone = Color(0xffa9a39b)
private val Ash = Color(0xff6b655f)
private val Hairline = Color(0xff2c2824)

// ---------------------------------------------------------------------------
// Screen
// ---------------------------------------------------------------------------
@Composable
fun PhoneView(modifier: Modifier = Modifier) {
    // Material3 hands every Text a default line height / letter spacing.
    // Resetting it keeps the text looking like the Figma design.
    CompositionLocalProvider(LocalTextStyle provides TextStyle.Default) {
        LazyColumn(modifier = modifier.fillMaxWidth().background(Ink)) {
            item { Hero() }
            item { Mindset() }
            item { Origin() }
            item { ByTheNumbers() }
            item { Racecraft() }
            item { RedChapter() }
            item { BeyondTheGrid() }
            item { PortraitQuote() }
            item { NextLap() }
            item { Footer() }
        }
    }
}

// ---------------------------------------------------------------------------
// Small reusable pieces
// ---------------------------------------------------------------------------
@Composable
private fun Rule(color: Color, modifier: Modifier = Modifier) {
    Box(modifier.background(color))
}

@Composable
private fun Kicker(text: String, color: Color = Ember, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = color,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = modifier,
    )
}

/** Full-width photo with a colour overlay; [content] is laid out on top of it. */
@Composable
private fun PhotoCard(
    image: Int,
    description: String,
    height: Dp,
    overlay: Brush,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Box(modifier.fillMaxWidth().height(height)) {
        Image(
            painter = painterResource(id = image),
            contentDescription = description,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        Box(Modifier.fillMaxSize().background(overlay))
        Column(
            verticalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxSize().padding(24.dp),
            content = content,
        )
    }
}

// ---------------------------------------------------------------------------
// 01 - Hero
// ---------------------------------------------------------------------------
@Composable
private fun Hero() {
    Column(Modifier.fillMaxWidth().background(Ink)) {
        Column(
            verticalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .height(560.dp)
                .background(
                    Brush.verticalGradient(
                        0f to Ink,
                        0.65f to Ink.copy(alpha = 0.8f),
                        1f to Ink,
                    )
                )
                .padding(20.dp),
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("LH", color = Color.White, fontSize = 20.sp)
                    Rule(Hairline, Modifier.size(width = 1.dp, height = 18.dp))
                    Text("THE RELENTLESS PURSUIT", color = Stone, fontSize = 10.sp)
                }
                ExploreChip()
            }

            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Rule(Ember, Modifier.size(width = 64.dp, height = 2.dp))
                    Text(
                        "SEVEN-TIME WORLD CHAMPION",
                        color = Ember,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Text(
                    text = "LEWIS\nHAMILTON",
                    color = Color.White,
                    fontSize = 56.sp,
                    lineHeight = 1.02.em,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    text = "Speed is the visible part. The real story is the discipline, resistance and reinvention behind every lap.",
                    color = Stone,
                    fontSize = 15.sp,
                    lineHeight = 1.55.em,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text("2007 - ∞", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(Ember))
                        Text("SCROLL TO ENTER", color = Stone, fontSize = 10.sp)
                    }
                }
            }
        }

        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 24.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Lewis Hamilton", color = Color.White, fontSize = 13.sp)
                Text(
                    "2008 2014 2015 2017 2018 2019 2020",
                    color = Ash,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                )
            }
            Text("01 / 10", color = Ash, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ExploreChip() {
    val shape = RoundedCornerShape(50)
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(shape)
            .border(1.dp, Hairline, shape)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    ) {
        Text("EXPLORE", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Image(
            painter = painterResource(id = R.drawable.arrowupright),
            contentDescription = "arrow-up-right",
            modifier = Modifier.size(12.dp),
        )
    }
}

// ---------------------------------------------------------------------------
// 02 - The mindset
// ---------------------------------------------------------------------------
@Composable
private fun Mindset() {
    Column(
        verticalArrangement = Arrangement.spacedBy(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .background(Paper)
            .padding(horizontal = 20.dp, vertical = 32.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            Kicker("02 - THE MINDSET", Rust)
            Text(
                "TALENT OPENS THE DOOR. WORK KEEPS IT OPEN.",
                color = Ash,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
            )
        }
        Text(
            text = buildAnnotatedString {
                withStyle(SpanStyle(color = Ink)) { append("NEVER ARRIVE. NEVER SETTLE. ") }
                withStyle(SpanStyle(color = Rust)) { append("KEEP PUSHING") }
                withStyle(SpanStyle(color = Ink)) { append(" UNTIL THE IMPOSSIBLE BECOMES THE STANDARD.") }
            },
            fontSize = 36.sp,
            lineHeight = 1.08.em,
            modifier = Modifier.fillMaxWidth(),
        )
        Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            Rule(Ink.copy(alpha = 0.2f), Modifier.fillMaxWidth().height(1.dp))
            Text(
                text = "From Stevenage to the summit of Formula One, the path was never conventional—and never meant to be.",
                color = Ash,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                lineHeight = 1.6.em,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

// ---------------------------------------------------------------------------
// 03 - Origin / ascent
// ---------------------------------------------------------------------------
@Composable
private fun Origin() {
    Column(
        verticalArrangement = Arrangement.spacedBy(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel)
            .padding(horizontal = 20.dp, vertical = 32.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(18.dp), modifier = Modifier.fillMaxWidth()) {
                Kicker("03 - ORIGIN / ASCENT", modifier = Modifier.fillMaxWidth())
                Text(
                    "BUILT OUTSIDE THE LINES.",
                    color = Color.White,
                    fontSize = 44.sp,
                    lineHeight = 0.94.em,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Text("01", color = Ember, fontSize = 48.sp)
                    Text(
                        text = "No inherited seat. No familiar blueprint. Just rare conviction, a father's sacrifice and a young driver learning to make every millisecond count. The climb began in karting and accelerated through every category that followed.",
                        color = Stone,
                        fontSize = 15.sp,
                        lineHeight = 1.65.em,
                        modifier = Modifier.weight(1f),
                    )
                }
                Text(
                    "THE OUTSIDER BECAME THE REFERENCE.",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            PhotoCard(
                image = R.drawable.trackimage,
                description = "Track image",
                height = 320.dp,
                overlay = Brush.verticalGradient(
                    0f to Color.Black.copy(alpha = 0.03f),
                    1f to Color.Black.copy(alpha = 0.8f),
                ),
                modifier = Modifier.clip(MaterialTheme.shapes.medium),
            ) {
                Text(
                    "ARCHIVE 001 / THE BEGINNING",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    "Every great distance begins with a first corner.",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 1.12.em,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
            TimelineItem("1995", "The promise", "First British karting title")
            TimelineItem("2007", "The arrival", "Debut season. Four wins.")
            TimelineItem("2008", "The breakthrough", "World champion at 23")
            TimelineItem("2014-20", "The era", "Six titles in seven seasons")
        }
    }
}

@Composable
private fun TimelineItem(year: String, title: String, caption: String) {
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth().padding(end = 18.dp, top = 18.dp),
    ) {
        Text(year, color = Ember, fontSize = 12.sp)
        Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
        Text(caption, color = Ash, fontSize = 11.sp, modifier = Modifier.fillMaxWidth())
    }
}

// ---------------------------------------------------------------------------
// 04 - By the numbers
// ---------------------------------------------------------------------------
@Composable
private fun ByTheNumbers() {
    Column(
        verticalArrangement = Arrangement.spacedBy(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .background(Ink)
            .padding(horizontal = 20.dp, vertical = 32.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
                Kicker("04 - BY THE NUMBERS", modifier = Modifier.fillMaxWidth())
                Text(
                    "A CAREER WITHOUT PRECEDENT.",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineLarge,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Text(
                text = "Records tell one version of the story. The margins, recoveries and pressure behind them tell the rest.",
                color = Stone,
                fontSize = 14.sp,
                lineHeight = 1.55.em,
                modifier = Modifier.fillMaxWidth(),
            )
        }

        // The Figma export nested a LazyColumn here, which crashes inside another
        // LazyColumn. A plain Column with four cards does the same job.
        Column(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
            StatCard("01", "7", 80.sp, "World titles", "Joint all-time record", highlighted = true)
            StatCard("02", "105", 72.sp, "Grand Prix wins", "Most in Formula One history")
            StatCard("03", "104", 80.sp, "Pole positions", "Precision over one lap")
            StatCard("04", "202", 72.sp, "Podium finishes", "Relentless consistency")
        }
    }
}

@Composable
private fun StatCard(
    index: String,
    value: String,
    valueSize: TextUnit,
    title: String,
    caption: String,
    highlighted: Boolean = false,
) {
    val background = if (highlighted) Ember else Panel
    val borderColor = if (highlighted) Ember else Hairline
    val foreground = if (highlighted) Ink else Color.White
    Column(
        verticalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 220.dp)
            .background(background)
            .border(BorderStroke(1.dp, borderColor))
            .padding(24.dp),
    ) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(
                index,
                color = if (highlighted) Ink else Ash,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
            )
            Box(Modifier.size(8.dp).background(if (highlighted) Ink else Ember))
        }
        Text(
            text = value,
            color = foreground,
            fontSize = valueSize,
            lineHeight = 0.8.em,
            modifier = Modifier.fillMaxWidth(),
        )
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Rule(
                if (highlighted) Ink.copy(alpha = 0.33f) else Hairline,
                Modifier.fillMaxWidth().height(1.dp),
            )
            Text(
                title,
                color = foreground,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                caption,
                color = if (highlighted) Color(0xff341006) else Ash,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                lineHeight = 1.45.em,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

// ---------------------------------------------------------------------------
// 05 - Racecraft
// ---------------------------------------------------------------------------
@Composable
private fun Racecraft() {
    Column(Modifier.fillMaxWidth().background(Ink)) {
        Box(Modifier.fillMaxWidth().height(420.dp)) {
            // Image first, overlay second, text last: later children draw on top.
            Image(
                painter = painterResource(id = R.drawable.nightrace),
                contentDescription = "Night race",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        0f to Color.Black.copy(alpha = 0.13f),
                        0.65f to Color.Black.copy(alpha = 0.25f),
                        1f to Color.Black.copy(alpha = 0.93f),
                    )
                )
            )
            Column(Modifier.fillMaxSize()) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 20.dp),
                ) {
                    Kicker("05 - RACECRAFT")
                    Text("51.2076° N / 1.0145° W", color = Color.White, fontSize = 10.sp)
                }
                Column(
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 20.dp, end = 20.dp, bottom = 24.dp),
                ) {
                    Text(
                        "FAST IS NOT ENOUGH.",
                        color = Color.White,
                        fontSize = 58.sp,
                        lineHeight = 0.9.em,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        "The defining laps happen where data ends: braking by feel, finding grip in rain, and understanding the race before it unfolds.",
                        color = Stone,
                        fontSize = 16.sp,
                        lineHeight = 1.55.em,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }

        Column(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth().background(Panel),
        ) {
            RaceItem("01", "WET WEATHER", "Grip becomes instinct. Chaos becomes an advantage.")
            RaceItem("02", "TYRE LIFE", "Feel the surface, protect the future, attack at the right moment.")
            RaceItem("03", "RACE IQ", "Read the energy of the field before the move appears.")
        }
    }
}

@Composable
private fun RaceItem(number: String, title: String, body: String) {
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 38.dp),
    ) {
        Text(number, color = Ember, fontSize = 12.sp)
        Text(title, color = Color.White, style = MaterialTheme.typography.titleLarge, modifier = Modifier.fillMaxWidth())
        Text(body, color = Ash, fontSize = 13.sp, lineHeight = 1.55.em, modifier = Modifier.fillMaxWidth())
    }
}

// ---------------------------------------------------------------------------
// 06 - The red chapter
// ---------------------------------------------------------------------------
@Composable
private fun RedChapter() {
    Column(Modifier.fillMaxWidth().background(Paper)) {
        PhotoCard(
            image = R.drawable.redmachine,
            description = "Red machine",
            height = 320.dp,
            overlay = Brush.verticalGradient(
                0f to Color.Black,
                1f to Color.Black.copy(alpha = 0.73f),
            ),
            modifier = Modifier.clip(MaterialTheme.shapes.medium),
        ) {
            Text(
                "ARCHIVE 044 / MARANELLO",
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "A NEW COLOUR. THE SAME OBSESSION.",
                color = Color.White,
                fontSize = 12.sp,
                lineHeight = 1.5.em,
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Column(
            verticalArrangement = Arrangement.spacedBy(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 32.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(18.dp), modifier = Modifier.fillMaxWidth()) {
                Kicker("06 - THE RED CHAPTER", Rust)
                Text(
                    text = buildAnnotatedString {
                        withStyle(SpanStyle(color = Ink)) { append("DIFFERENT MACHINE.\n") }
                        withStyle(SpanStyle(color = Rust)) { append("SAME FIRE.") }
                    },
                    fontSize = 48.sp,
                    lineHeight = 0.96.em,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Text(
                text = "In 2025, the most successful driver of his generation chose reinvention again. Maranello is not a victory lap—it is another beginning, powered by belief that the next limit is still waiting.",
                color = Ash,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                lineHeight = 1.65.em,
                modifier = Modifier.fillMaxWidth(),
            )
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                FactBlock("44", "CAR NUMBER")
                FactBlock("2025", "FIRST SEASON")
                FactBlock("ITA", "NEW HOME")
            }
        }
    }
}

@Composable
private fun FactBlock(value: String, label: String) {
    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp),
    ) {
        Text(value, color = Ink, style = MaterialTheme.typography.titleLarge)
        Text(label, color = Ash, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth())
    }
}

// ---------------------------------------------------------------------------
// 07 - Beyond the grid
// ---------------------------------------------------------------------------
@Composable
private fun BeyondTheGrid() {
    Column(
        verticalArrangement = Arrangement.spacedBy(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel)
            .padding(horizontal = 20.dp, vertical = 32.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
                Kicker("07 - BEYOND THE GRID", modifier = Modifier.fillMaxWidth())
                Text("USE THE PLATFORM.", color = Color.White, fontSize = 42.sp, modifier = Modifier.fillMaxWidth())
            }
            Text(
                text = "Legacy is not only what happens at 300 km/h. It is what changes because someone decided silence was no longer enough.",
                color = Stone,
                fontSize = 15.sp,
                lineHeight = 1.6.em,
                modifier = Modifier.fillMaxWidth(),
            )
        }

        Column(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
            MissionCard(
                label = "MISSION 44",
                labelColor = Ash,
                icon = R.drawable.compass,
                iconDescription = "compass",
                iconTint = Stone,
                number = "01",
                numberColor = Color.White.copy(alpha = 0.04f),
                title = "Opportunity",
                body = "Opening routes into STEM and motorsport for young people from underrepresented backgrounds.",
                background = Ink,
                borderColor = Hairline,
            )
            MissionCard(
                label = "THE HAMILTON COMMISSION",
                labelColor = Ember,
                icon = R.drawable.circlex,
                iconDescription = "circle-x",
                iconTint = Ember,
                number = "02",
                numberColor = Ember.copy(alpha = 0.13f),
                title = "Representation",
                body = "Research, accountability and action to build a more inclusive motorsport industry.",
                background = PanelWarm,
                borderColor = Ember,
            )
            MissionCard(
                label = "LOWER IMPACT",
                labelColor = Ash,
                icon = R.drawable.treepine,
                iconDescription = "tree-pine",
                iconTint = Stone,
                number = "03",
                numberColor = Color.White.copy(alpha = 0.04f),
                title = "Responsibility",
                body = "Using visibility to accelerate better choices for people, animals and the planet.",
                background = Ink,
                borderColor = Hairline,
            )
        }
    }
}

@Composable
private fun MissionCard(
    label: String,
    labelColor: Color,
    icon: Int,
    iconDescription: String,
    iconTint: Color,
    number: String,
    numberColor: Color,
    title: String,
    body: String,
    background: Color,
    borderColor: Color,
) {
    Column(
        verticalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .background(background)
            .border(BorderStroke(1.dp, borderColor))
            .padding(28.dp),
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(label, color = labelColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Image(
                painter = painterResource(id = icon),
                contentDescription = iconDescription,
                colorFilter = ColorFilter.tint(iconTint),
                modifier = Modifier.size(28.dp),
            )
        }
        Text(number, color = numberColor, fontSize = 72.sp, lineHeight = 0.8.em)
        Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            Text(title, color = Color.White, style = MaterialTheme.typography.titleLarge, modifier = Modifier.fillMaxWidth())
            Text(body, color = Ash, fontSize = 13.sp, lineHeight = 1.55.em, modifier = Modifier.fillMaxWidth())
        }
    }
}

// ---------------------------------------------------------------------------
// 08 - Portrait + quote
// ---------------------------------------------------------------------------
@Composable
private fun PortraitQuote() {
    Column(Modifier.fillMaxWidth().background(Ink)) {
        PhotoCard(
            image = R.drawable.portrait,
            description = "Portrait",
            height = 320.dp,
            overlay = SolidColor(Ember.copy(alpha = 0.2f)),
        ) {
            Text("PORTRAIT / STUDY 44", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text("08 / 10", color = Color.White, fontSize = 12.sp)
        }

        Column(
            verticalArrangement = Arrangement.spacedBy(24.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 32.dp),
        ) {
            Text("“", color = Ember, fontSize = 64.sp, lineHeight = 0.7.em)
            Text(
                text = "YOU CAN KNOCK ME DOWN, BUT I GET UP TWICE AS STRONG.",
                color = Color.White,
                style = MaterialTheme.typography.displaySmall,
                lineHeight = 1.08.em,
                modifier = Modifier.fillMaxWidth(),
            )
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                Rule(Hairline, Modifier.width(260.dp).height(1.dp))
                Text("LEWIS HAMILTON", color = Stone, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ---------------------------------------------------------------------------
// 09 - The next lap
// ---------------------------------------------------------------------------
@Composable
private fun NextLap() {
    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(520.dp)) {
            Image(
                painter = painterResource(id = R.drawable.circuitaerial),
                contentDescription = "Circuit aerial",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.53f)))
            Column(
                verticalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 24.dp),
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Kicker("09 - THE NEXT LAP")
                    Text("STORY IN MOTION", color = Color.White, fontSize = 10.sp)
                }
                Column(verticalArrangement = Arrangement.spacedBy(24.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "STILL WE RISE.",
                        color = Color.White,
                        fontSize = 84.sp,
                        lineHeight = 0.85.em,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        "The records are written. The work is not. Follow a career that continues to redefine what a champion can be.",
                        color = Stone,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 1.6.em,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(Ember)
                            .padding(horizontal = 22.dp, vertical = 15.dp),
                    ) {
                        Text("ENTER THE ARCHIVE", color = Ink, fontSize = 11.sp)
                        Image(
                            painter = painterResource(id = R.drawable.arrowupright),
                            contentDescription = "arrow-up-right",
                            colorFilter = ColorFilter.tint(Ink),
                            modifier = Modifier.size(14.dp),
                        )
                    }
                }
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 24.dp),
        ) {
            Rule(Ember, Modifier.size(width = 140.dp, height = 2.dp))
            Rule(Color.White.copy(alpha = 0.2f), Modifier.weight(1f).height(1.dp))
            Text("09 / 10", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// ---------------------------------------------------------------------------
// 10 - Footer
// ---------------------------------------------------------------------------
@Composable
private fun Footer() {
    Column(
        verticalArrangement = Arrangement.spacedBy(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .background(Ink)
            .padding(horizontal = 20.dp, vertical = 24.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(18.dp), modifier = Modifier.fillMaxWidth()) {
                Text("LH44", color = Color.White, fontSize = 42.sp)
                Text(
                    "An independent editorial tribute to a racer, activist and relentless believer in what comes next.",
                    color = Ash,
                    fontSize = 12.sp,
                    lineHeight = 1.55.em,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
                FooterLinks("EXPLORE", listOf("Origin", "Records", "Racecraft", "Impact"))
                FooterLinks("FOLLOW", listOf("Instagram", "YouTube", "X / Twitter", "Mission 44"))
                Column(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "The next chapter, delivered.",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    ) {
                        Text("EMAIL ADDRESS", color = Ash, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        Image(
                            painter = painterResource(id = R.drawable.arrowright),
                            contentDescription = "arrow-right",
                            colorFilter = ColorFilter.tint(Ash),
                            modifier = Modifier.size(16.dp),
                        )
                    }
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            Text(
                "© 2026 EDITORIAL CONCEPT. ALL RIGHTS RESERVED.",
                color = Ash,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
            )
            Rule(Ember, Modifier.size(width = 220.dp, height = 2.dp))
            Text("10 / 10 - END / BEGIN", color = Ash, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun FooterLinks(heading: String, links: List<String>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        Text(heading, color = Ember, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        links.forEach { Text(it, color = Stone, fontSize = 12.sp) }
    }
}

@Preview(widthDp = 402, heightDp = 7957)
@Composable
private fun PhoneViewPreview() {
    PhoneView(Modifier)
}
